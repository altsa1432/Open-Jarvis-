@echo off
setlocal
set GRADLE_VERSION=8.13
if "%GRADLE_USER_HOME%"=="" set GRADLE_USER_HOME=%USERPROFILE%\.gradle
set GRADLE_BASE=%GRADLE_USER_HOME%\open-jarvis-dist
set GRADLE_HOME_DIR=%GRADLE_BASE%\gradle-%GRADLE_VERSION%
set GRADLE_BIN=%GRADLE_HOME_DIR%\bin\gradle.bat
if not exist "%GRADLE_BIN%" (
  if not exist "%GRADLE_BASE%" mkdir "%GRADLE_BASE%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%GRADLE_BASE%\gradle-%GRADLE_VERSION%-bin.zip'; Expand-Archive -Force '%GRADLE_BASE%\gradle-%GRADLE_VERSION%-bin.zip' '%GRADLE_BASE%'; Remove-Item '%GRADLE_BASE%\gradle-%GRADLE_VERSION%-bin.zip'"
  if errorlevel 1 goto :download_error
)
call "%GRADLE_BIN%" %*
exit /b %errorlevel%
:download_error
exit /b 1
