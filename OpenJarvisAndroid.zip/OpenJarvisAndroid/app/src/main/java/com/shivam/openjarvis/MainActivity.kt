package com.shivam.openjarvis

import android.Manifest
import android.animation.ValueAnimator
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var answerText: TextView
    private lateinit var commandText: TextView
    private lateinit var commandInput: EditText
    private lateinit var cameraManager: CameraManager
    private lateinit var audioManager: AudioManager
    private var torchOn = false
    private var pendingTorchState = false
    private var speechEngine: TextToSpeech? = null
    private var speechReady = false

    companion object {
        private const val REQUEST_SPEECH = 7101
        private const val REQUEST_MIC_PERMISSION = 7102
        private const val REQUEST_CAMERA_PERMISSION = 7103
        const val C_WHITE: Int = -657665
        const val C_MUTED: Int = -7497800
        const val C_SUBTLE: Int = -5392944
        const val C_LAVENDER: Int = -5266689
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 11, 22)
        window.navigationBarColor = Color.rgb(8, 11, 22)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        speechEngine = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val engine = speechEngine
                val result = engine?.setLanguage(Locale("hi", "IN"))
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    engine?.language = Locale.getDefault()
                }
                speechReady = true
            }
        }
        buildInterface()
    }

    private fun buildInterface() {
        val scroller = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setBackgroundColor(Color.rgb(8, 11, 22))
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(18), dp(22), dp(28))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(8, 11, 22), Color.rgb(15, 19, 39), Color.rgb(8, 11, 22))
            )
        }
        scroller.addView(content)
        setContentView(scroller)

        content.addView(buildHeader(), matchWrap())
        addSpace(content, 27)
        content.addView(label("PERSONAL ASSISTANT", 10f, C_MUTED, true).apply { letterSpacing = 0.18f })
        addSpace(content, 7)
        content.addView(label("Your phone.\nYour command.", 31f, C_WHITE, true).apply {
            letterSpacing = -0.035f
            setLineSpacing(dp(1).toFloat(), 1.0f)
        })
        addSpace(content, 7)
        content.addView(label("Speak naturally. Jarvis will handle the action.", 14f, C_SUBTLE, false))
        addSpace(content, 6)

        val orbFrame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, dp(238)).apply {
                topMargin = dp(9)
                bottomMargin = dp(0)
            }
            contentDescription = "Tap to speak to Open Jarvis"
            isClickable = true
            isFocusable = true
            setOnClickListener { startVoiceInput() }
        }
        orbFrame.addView(JarvisOrbView(this), FrameLayout.LayoutParams(-1, -1))
        content.addView(orbFrame)
        content.addView(label("✦   TAP THE CORE TO SPEAK   ✦", 10f, C_LAVENDER, true).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.12f
        }, matchWrap())
        addSpace(content, 24)

        content.addView(buildCommandComposer(), matchWrap())
        addSpace(content, 23)
        val section = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        section.addView(label("QUICK CONTROLS", 12f, C_WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        section.addView(label("6 shortcuts", 11f, C_MUTED, false))
        content.addView(section)
        addSpace(content, 12)
        addActionRow(content, listOf(
            QuickAction("⚡", "Flashlight", "Toggle torch", "flashlight"),
            QuickAction("＋", "Volume up", "Raise media volume", "volume up")
        ))
        addSpace(content, 10)
        addActionRow(content, listOf(
            QuickAction("▶", "YouTube", "Open video app", "open youtube"),
            QuickAction("◈", "Settings", "Open device settings", "open settings")
        ))
        addSpace(content, 10)
        addActionRow(content, listOf(
            QuickAction("ᛒ", "Bluetooth", "Open connection settings", "open bluetooth"),
            QuickAction("⌁", "Wi-Fi / Internet", "Open network panel", "open wifi")
        ))
        addSpace(content, 21)

        val resultCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(15))
            background = rounded(
                intArrayOf(Color.rgb(20, 25, 47), Color.rgb(16, 21, 39)),
                20,
                Color.rgb(48, 55, 88)
            )
        }
        resultCard.addView(label("LATEST RESPONSE", 10f, C_LAVENDER, true).apply { letterSpacing = 0.13f })
        addSpace(resultCard, 7)
        commandText = label("READY FOR YOUR COMMAND", 12f, C_MUTED, true)
        resultCard.addView(commandText)
        addSpace(resultCard, 6)
        answerText = label("Hi! Tap the glowing core or type a command below.", 14f, C_WHITE, false)
        answerText.setLineSpacing(dp(3).toFloat(), 1.0f)
        resultCard.addView(answerText)
        content.addView(resultCard, matchWrap())
        addSpace(content, 17)
        content.addView(label("TRY:  “Open YouTube”  ·  “Torch on”  ·  “Battery status”", 11f, C_SUBTLE, false).apply {
            gravity = Gravity.CENTER
            setLineSpacing(dp(4).toFloat(), 1f)
        })
        addSpace(content, 12)
        content.addView(label("Voice recognition uses the speech service available on your phone. Some services may use the internet. Protected system actions open their official settings screen instead of bypassing Android security.", 10f, C_MUTED, false).apply {
            gravity = Gravity.CENTER
            setLineSpacing(dp(3).toFloat(), 1f
            )
        })
    }

    private fun buildHeader(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logo = TextView(this).apply {
            text = "✦"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(C_WHITE)
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(132, 99, 255), Color.rgb(54, 113, 244))
            ).apply { cornerRadius = dp(16).toFloat() }
        }
        row.addView(logo, LinearLayout.LayoutParams(dp(48), dp(48)))
        val brand = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        brand.addView(label("OPEN JARVIS", 15f, C_WHITE, true).apply { letterSpacing = 0.09f })
        addSpace(brand, 4)
        brand.addView(label("ANDROID ASSISTANT", 9f, C_MUTED, true).apply { letterSpacing = 0.13f })
        row.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val online = TextView(this).apply {
            text = "●  READY"
            textSize = 10f
            letterSpacing = 0.03f
            setTextColor(Color.rgb(128, 237, 189))
            gravity = Gravity.CENTER
            setPadding(dp(11), dp(8), dp(11), dp(8))
            background = rounded(intArrayOf(Color.rgb(20, 49, 47), Color.rgb(17, 39, 42)), 100, Color.rgb(42, 91, 80))
        }
        row.addView(online)
        return row
    }

    private fun buildCommandComposer(): View {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(8), dp(8))
            background = rounded(intArrayOf(Color.rgb(21, 26, 48), Color.rgb(16, 21, 39)), 20, Color.rgb(60, 65, 100))
        }
        commandInput = EditText(this).apply {
            hint = "Type a command…"
            setHintTextColor(Color.rgb(132, 141, 168))
            setTextColor(C_WHITE)
            textSize = 14f
            maxLines = 1
            singleLine = true
            imeOptions = EditorInfo.IME_ACTION_DONE
            setPadding(dp(8), dp(8), dp(4), dp(8))
            background = null
            isSaveEnabled = true
            setOnEditorActionListener { _, actionId, event ->
                if (actionId == EditorInfo.IME_ACTION_DONE || (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)) {
                    val text = commandInput.text?.toString().orEmpty()
                    if (text.isNotBlank()) executeCommand(text)
                    true
                } else false
            }
        }
        outer.addView(commandInput, LinearLayout.LayoutParams(0, dp(46), 1f))
        val go = TextView(this).apply {
            text = "RUN  ↗"
            textSize = 11f
            letterSpacing = 0.04f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(dp(15), 0, dp(15), 0)
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(128, 93, 255), Color.rgb(64, 108, 244))
            ).apply { cornerRadius = dp(14).toFloat() }
            isClickable = true
            isFocusable = true
            setOnClickListener {
                val text = commandInput.text?.toString().orEmpty()
                if (text.isBlank()) {
                    showResponse("Type a command first, for example ‘open YouTube’.", false)
                } else executeCommand(text)
            }
        }
        outer.addView(go, LinearLayout.LayoutParams(dp(88), dp(46)))
        return outer
    }

    private data class QuickAction(val icon: String, val title: String, val subtitle: String, val command: String)

    private fun addActionRow(parent: LinearLayout, actions: List<QuickAction>) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.forEachIndexed { index, action ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(12), dp(10), dp(12))
                background = rounded(intArrayOf(Color.rgb(22, 27, 50), Color.rgb(15, 20, 39)), 18, Color.rgb(45, 52, 82))
                isClickable = true
                isFocusable = true
                setOnClickListener { executeCommand(action.command) }
                contentDescription = "${action.title}. ${action.subtitle}"
            }
            card.addView(label(action.icon, 19f, C_LAVENDER, true))
            addSpace(card, 8)
            card.addView(label(action.title, 13f, C_WHITE, true))
            addSpace(card, 3)
            card.addView(label(action.subtitle, 10f, C_MUTED, false))
            val params = LinearLayout.LayoutParams(0, dp(106), 1f)
            if (index == 0) params.rightMargin = dp(6) else params.leftMargin = dp(6)
            row.addView(card, params)
        }
        parent.addView(row, matchWrap())
    }

    private fun startVoiceInput() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_MIC_PERMISSION)
            return
        }
        launchVoiceRecognizer()
    }

    private fun launchVoiceRecognizer() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Jarvis ko command dein / Speak your command")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try {
            startActivityForResult(intent, REQUEST_SPEECH)
        } catch (_: ActivityNotFoundException) {
            showResponse("No speech recognition app is available. Type your command in the box instead.", true)
        }
    }

    @Deprecated("Android's built-in speech recognizer returns results through this activity callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_SPEECH && resultCode == RESULT_OK) {
            val matches = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val recognized = matches?.firstOrNull().orEmpty()
            if (recognized.isNotBlank()) {
                commandInput.setText(recognized)
                executeCommand(recognized)
            } else showResponse("I couldn't catch that. Please try again.", true)
        }
    }

    @Deprecated("Permission result callback required by this minimal-dependency Activity")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            REQUEST_MIC_PERMISSION -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) launchVoiceRecognizer()
                else showResponse("Microphone permission was denied. You can still type commands.", true)
            }
            REQUEST_CAMERA_PERMISSION -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) setTorch(pendingTorchState)
                else showResponse("Camera permission is needed for the flashlight on this device.", true)
            }
        }
    }

    private fun executeCommand(raw: String) {
        val normalized = raw.trim().lowercase(Locale.ROOT)
            .replace(Regex("[.!?,]"), " ")
            .replace(Regex("\\s+"), " ")
            .removePrefix("hey jarvis ")
            .removePrefix("jarvis ")
            .trim()
        if (normalized.isBlank()) return

        if (containsAny(normalized, "flashlight", "flash light", "torch", "टॉर्च", "torchlight")) {
            val turnOff = containsAny(normalized, "off", "बंद", "band", "bujha", "बुझा")
            val turnOn = containsAny(normalized, "on", "चालू", "chalu", "jalao", "जलाओ")
            val target = when {
                turnOff -> false
                turnOn -> true
                else -> !torchOn
            }
            requestTorch(target)
            return
        }

        if (containsAny(normalized, "volume", "आवाज", "आवाज़", "वॉल्यूम", "sound")) {
            when {
                containsAny(normalized, "up", "increase", "raise", "बढ़ा", "बढ़ा", "ऊपर", "तेज", "तेज़") -> {
                    audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                    showResponse("Media volume increased.", true)
                }
                containsAny(normalized, "down", "decrease", "lower", "कम", "घटा", "नीचे") -> {
                    audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                    showResponse("Media volume decreased.", true)
                }
                containsAny(normalized, "unmute", "आवाज चालू", "आवाज़ चालू") -> {
                    audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI)
                    showResponse("Media audio unmuted.", true)
                }
                containsAny(normalized, "mute", "silent", "आवाज बंद", "आवाज़ बंद") -> {
                    audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                    showResponse("Media audio muted.", true)
                }
                else -> showResponse("Try ‘volume up’, ‘volume down’ or ‘mute volume’.", true)
            }
            return
        }

        if (containsAny(normalized, "battery", "बैटरी", "charge level", "battery status")) {
            val battery = getSystemService(BATTERY_SERVICE) as BatteryManager
            val level = battery.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            showResponse(if (level in 0..100) "Battery is at $level percent." else "Battery level is unavailable.", true)
            return
        }
        if (containsAny(normalized, "what time", "time now", "current time", "समय", "टाइम", "time batao")) {
            val time = LocalDateTime.now().format(DateTimeFormatter.ofPattern("h:mm a", Locale.getDefault()))
            showResponse("The time is $time.", true)
            return
        }
        if (containsAny(normalized, "today's date", "today date", "what date", "date today", "तारीख", "आज कौन सा दिन", "आज की डेट")) {
            val date = LocalDateTime.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.getDefault()))
            showResponse("Today is $date.", true)
            return
        }

        if (normalized == "home" || containsAny(normalized, "go home", "home screen", "होम स्क्रीन", "होम पर जाओ")) {
            requestGlobalAction("home", "Home")
            return
        }
        if (normalized == "back" || containsAny(normalized, "go back", "press back", "back button", "वापस जाओ", "पीछे जाओ")) {
            requestGlobalAction("back", "Back")
            return
        }
        if (containsAny(normalized, "recent apps", "open recents", "show recent", "हाल के ऐप", "recent app")) {
            requestGlobalAction("recents", "Recent apps")
            return
        }
        if (containsAny(normalized, "notification panel", "open notifications", "show notifications", "नोटिफिकेशन खोलो", "सूचनाएं खोलो")) {
            requestGlobalAction("notifications", "Notifications")
            return
        }
        if (containsAny(normalized, "quick settings", "open control center", "control center", "क्विक सेटिंग")) {
            requestGlobalAction("quick_settings", "Quick settings")
            return
        }

        if (containsAny(normalized, "wifi", "wi-fi", "वाईफाई", "internet", "नेट") ) {
            openInternetPanel()
            return
        }
        if (containsAny(normalized, "bluetooth", "ब्लूटूथ")) {
            openSystemSettings(Intent(Settings.ACTION_BLUETOOTH_SETTINGS), "Bluetooth settings opened. Switch it on or off there.")
            return
        }
        if (containsAny(normalized, "display settings", "brightness", "screen brightness", "ब्राइटनेस")) {
            openSystemSettings(Intent(Settings.ACTION_DISPLAY_SETTINGS), "Display settings opened. You can adjust brightness there.")
            return
        }
        if (containsAny(normalized, "settings", "सेटिंग", "सेटिंग्स")) {
            openSystemSettings(Intent(Settings.ACTION_SETTINGS), "Device settings opened.")
            return
        }
        if (containsAny(normalized, "alarm", "अलार्म", "wake me")) {
            openSystemSettings(Intent(AlarmClock.ACTION_SHOW_ALARMS), "Alarm app opened.")
            return
        }
        if (containsAny(normalized, "camera", "कैमरा", "photo lo", "take a photo")) {
            openSystemSettings(Intent(MediaStore.ACTION_IMAGE_CAPTURE), "Camera opened. Take the photo in the camera app.")
            return
        }
        if (containsAny(normalized, "gallery", "photos", "गैलरी", "फोटो")) {
            openApp("com.google.android.apps.photos", "Photos", "https://photos.google.com")
            return
        }
        if (containsAny(normalized, "youtube", "यूट्यूब")) {
            openApp("com.google.android.youtube", "YouTube", "https://www.youtube.com")
            return
        }
        if (containsAny(normalized, "whatsapp", "व्हाट्सएप", "व्हाट्सऐप")) {
            openApp("com.whatsapp", "WhatsApp", "https://wa.me/")
            return
        }
        if (containsAny(normalized, "chrome", "browser", "ब्राउज़र", "internet browser")) {
            openApp("com.android.chrome", "Chrome", "https://www.google.com")
            return
        }
        if (containsAny(normalized, "google maps", "maps", "map kholo", "मैप")) {
            openApp("com.google.android.apps.maps", "Maps", "https://maps.google.com")
            return
        }
        if (containsAny(normalized, "gmail", "email", "ईमेल")) {
            openApp("com.google.android.gm", "Gmail", "mailto:")
            return
        }
        if (containsAny(normalized, "calculator", "कैलकुलेटर", "hisab", "हिसाब")) {
            val calc = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALCULATOR)
            openSystemSettings(calc, "Calculator opened.", "Calculator app not found on this phone.")
            return
        }
        if (containsAny(normalized, "message app", "messages", "sms inbox", "मैसेज", "संदेश")) {
            val messages = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING)
            openSystemSettings(messages, "Messaging app opened.", "No messaging app was found.")
            return
        }
        if (containsAny(normalized, "dialer", "phone app", "call someone", "फोन", "call")) {
            openSystemSettings(Intent(Intent.ACTION_DIAL), "Dialer opened. Review the number and start a call yourself.")
            return
        }
        if (containsAny(normalized, "contacts", "contact list", "कॉन्टैक्ट")) {
            openSystemSettings(Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI), "Contacts opened.")
            return
        }
        if (containsAny(normalized, "music", "play song", "gaana", "गाना", "music player")) {
            val music = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MUSIC)
            openSystemSettings(music, "Music app opened.", "No music player was found.")
            return
        }

        val searchPrefix = listOf("search for ", "search ", "google ", "look up ", "find on google ")
            .firstOrNull { normalized.startsWith(it) }
        if (searchPrefix != null) {
            val query = normalized.removePrefix(searchPrefix).trim()
            if (query.isNotBlank()) {
                val url = "https://www.google.com/search?q=" + Uri.encode(query)
                openSystemSettings(Intent(Intent.ACTION_VIEW, Uri.parse(url)), "Searching the web for: $query")
            } else showResponse("Tell me what you want to search for.", true)
            return
        }

        if (containsAny(normalized, "lock phone", "phone lock", "screen lock", "restart phone", "reboot phone", "shutdown", "screenshot", "take screenshot")) {
            showResponse("That action is protected by Android. Use your phone's power/quick-settings controls, or set up a dedicated Accessibility or device-owner workflow with explicit consent.", true)
            return
        }

        showResponse("I didn't recognize that command yet. Try ‘open YouTube’, ‘open Wi-Fi settings’, ‘torch on’, ‘volume down’ or ‘battery status’.", true)
    }

    private fun requestGlobalAction(action: String, displayName: String) {
        val component = android.content.ComponentName(this, JarvisAccessibilityService::class.java)
        val enabledServices = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
        val enabled = enabledServices.split(':').any { android.content.ComponentName.unflattenFromString(it) == component }
        if (!enabled) {
            showResponse("To use $displayName voice commands, enable ‘Open Jarvis navigation controls’ in Accessibility settings. This optional service only performs requested system navigation actions; it does not read screen content or tap inside other apps.", false)
            try {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } catch (_: Exception) {
                Toast.makeText(this, "Open Settings > Accessibility to enable Open Jarvis navigation controls.", Toast.LENGTH_LONG).show()
            }
            return
        }
        val command = Intent(JarvisAccessibilityService.ACTION_PERFORM_GLOBAL_ACTION)
            .setPackage(packageName)
            .putExtra(JarvisAccessibilityService.EXTRA_GLOBAL_ACTION, action)
        sendBroadcast(command)
        showResponse("Sent the $displayName action to Android.", true)
    }

    private fun requestTorch(enable: Boolean) {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            pendingTorchState = enable
            requestPermissions(arrayOf(Manifest.permission.CAMERA), REQUEST_CAMERA_PERMISSION)
            return
        }
        setTorch(enable)
    }

    private fun setTorch(enable: Boolean) {
        try {
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (cameraId == null) {
                showResponse("This device doesn't report an available camera flash.", true)
                return
            }
            cameraManager.setTorchMode(cameraId, enable)
            torchOn = enable
            showResponse(if (enable) "Flashlight switched on." else "Flashlight switched off.", true)
        } catch (_: SecurityException) {
            showResponse("Android denied access to the flashlight. Check the camera permission in App settings.", true)
        } catch (_: CameraAccessException) {
            showResponse("The flashlight is busy or unavailable right now. Try again in a moment.", true)
        } catch (_: Exception) {
            showResponse("Couldn't change the flashlight state on this device.", true)
        }
    }

    private fun openInternetPanel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            openSystemSettings(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY), "Internet panel opened. Android requires you to confirm Wi-Fi or mobile-network changes there.")
        } else {
            openSystemSettings(Intent(Settings.ACTION_WIFI_SETTINGS), "Wi-Fi settings opened.")
        }
    }

    private fun openApp(packageName: String, displayName: String, fallbackUrl: String) {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            try {
                startActivity(launchIntent)
                showResponse("Opening $displayName.", true)
                return
            } catch (_: Exception) { /* Try the web or system fallback below. */ }
        }
        val fallback = if (fallbackUrl.startsWith("mailto:")) {
            Intent(Intent.ACTION_SENDTO, Uri.parse(fallbackUrl))
        } else Intent(Intent.ACTION_VIEW, Uri.parse(fallbackUrl))
        openSystemSettings(fallback, "$displayName isn't installed or isn't available. Opening its web alternative.", "$displayName couldn't be opened.")
    }

    private fun openSystemSettings(intent: Intent, successMessage: String, failureMessage: String = "That app or settings screen isn't available on this device.") {
        try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (intent.resolveActivity(packageManager) != null) {
                startActivity(intent)
                showResponse(successMessage, true)
            } else showResponse(failureMessage, true)
        } catch (_: Exception) {
            showResponse(failureMessage, true)
        }
    }

    private fun showResponse(message: String, speak: Boolean) {
        if (::commandText.isInitialized) commandText.text = "COMMAND  •  ${LocalDateTime.now().format(DateTimeFormatter.ofPattern("h:mm a", Locale.getDefault()))}"
        if (::answerText.isInitialized) answerText.text = message
        if (speak && speechReady) speechEngine?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "open-jarvis-response")
    }

    private fun containsAny(text: String, vararg terms: String): Boolean = terms.any { text.contains(it) }

    private fun label(text: String, size: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        else typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        includeFontPadding = true
    }

    private fun addSpace(parent: LinearLayout, height: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun matchWrap() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun rounded(colors: IntArray, radius: Int, stroke: Int): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TL_BR, colors
    ).apply {
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), stroke)
    }

    override fun onDestroy() {
        speechEngine?.stop()
        speechEngine?.shutdown()
        super.onDestroy()
    }

    private inner class JarvisOrbView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var angle = 0f
        private val animator = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 16000L
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener {
                angle = it.animatedValue as Float
                invalidate()
            }
        }

        init {
            animator.start()
            setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f
            val cy = height / 2f
            val density = resources.displayMetrics.density
            val scale = minOf(width / (320f * density), height / (238f * density)).coerceAtLeast(0.6f) * density
            val r1 = 95f * scale
            val r2 = 78f * scale
            val r3 = 61f * scale

            paint.style = Paint.Style.FILL
            paint.shader = RadialGradient(cx, cy, r1 * 1.65f,
                intArrayOf(0x553E64FF, 0x222D40B8, 0x00101628), null, Shader.TileMode.CLAMP)
            canvas.drawCircle(cx, cy, r1 * 1.65f, paint)
            paint.shader = null

            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 1.2f * density
            paint.color = 0x554E74FF
            canvas.drawCircle(cx, cy, r1, paint)
            paint.color = 0x667A69FF.toInt()
            canvas.drawCircle(cx, cy, r2, paint)
            paint.color = 0x3373B9FF
            canvas.drawCircle(cx, cy, r3, paint)

            canvas.save()
            canvas.rotate(angle, cx, cy)
            paint.style = Paint.Style.FILL
            paint.color = 0xFFD3CDFF.toInt()
            canvas.drawCircle(cx + r1, cy, 3.3f * density, paint)
            paint.color = 0xFF69D9FF.toInt()
            canvas.drawCircle(cx - r2, cy, 2.6f * density, paint)
            canvas.drawCircle(cx + r2 * 0.66f, cy - r2 * 0.66f, 2.1f * density, paint)
            canvas.restore()

            paint.shader = RadialGradient(cx - r3 * 0.25f, cy - r3 * 0.35f, r3 * 1.55f,
                intArrayOf(0xFF5AA8FF.toInt(), 0xFF705BFF.toInt(), 0xFF232B73.toInt()), null, Shader.TileMode.CLAMP)
            canvas.drawCircle(cx, cy, r3, paint)
            paint.shader = null
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 1.2f * density
            paint.color = 0xAA9FDFFF.toInt()
            canvas.drawCircle(cx, cy, r3, paint)

            // Microphone glyph in the centre of the orb.
            paint.style = Paint.Style.FILL
            paint.color = Color.WHITE
            val mic = RectF(cx - 7.5f * density, cy - 19f * density, cx + 7.5f * density, cy + 8f * density)
            canvas.drawRoundRect(mic, 8f * density, 8f * density, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2.1f * density
            paint.color = 0xFFF4F4FF.toInt()
            canvas.drawArc(RectF(cx - 15f * density, cy - 8f * density, cx + 15f * density, cy + 20f * density), 0f, 180f, false, paint)
            canvas.drawLine(cx, cy + 20f * density, cx, cy + 28f * density, paint)
            canvas.drawLine(cx - 8f * density, cy + 28f * density, cx + 8f * density, cy + 28f * density, paint)
        }

        override fun onDetachedFromWindow() {
            animator.cancel()
            super.onDetachedFromWindow()
        }
    }

}
