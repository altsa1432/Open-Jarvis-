package com.shivam.openjarvis

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

/**
 * Optional, user-enabled accessibility integration restricted to Android global actions.
 * It does not request window-content access, inspect accessibility nodes, or synthesize taps.
 */
class JarvisAccessibilityService : AccessibilityService() {
    companion object {
        const val ACTION_PERFORM_GLOBAL_ACTION = "com.shivam.openjarvis.PERFORM_GLOBAL_ACTION"
        const val EXTRA_GLOBAL_ACTION = "global_action"
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val action = intent.getStringExtra(EXTRA_GLOBAL_ACTION) ?: return
            val globalAction = when (action) {
                "home" -> GLOBAL_ACTION_HOME
                "back" -> GLOBAL_ACTION_BACK
                "recents" -> GLOBAL_ACTION_RECENTS
                "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
                "quick_settings" -> GLOBAL_ACTION_QUICK_SETTINGS
                else -> return
            }
            val succeeded = performGlobalAction(globalAction)
            if (!succeeded) {
                Toast.makeText(context, "Android could not perform that navigation action.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private var receiverRegistered = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        val filter = IntentFilter(ACTION_PERFORM_GLOBAL_ACTION)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(receiver, filter)
        }
        receiverRegistered = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally do not inspect screen text or other apps' accessibility content.
    }

    override fun onInterrupt() {
        // No ongoing interaction to interrupt.
    }

    override fun onDestroy() {
        if (receiverRegistered) {
            try { unregisterReceiver(receiver) } catch (_: IllegalArgumentException) { }
            receiverRegistered = false
        }
        super.onDestroy()
    }
}
